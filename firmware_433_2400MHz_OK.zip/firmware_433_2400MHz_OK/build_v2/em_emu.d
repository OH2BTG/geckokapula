build_v2/em_emu.o: ../gecko_sdk_suite/v2.7/platform/emlib/src/em_emu.c \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_emu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/em_device.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p233f256gm48.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_version.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_compiler.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_gcc.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/mpu_armv7.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/system_efr32fg14p.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_msc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_emu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rmu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_cmu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_crypto.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_gpio_p.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_gpio.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_prs_ch.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_prs.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_ldma_ch.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_ldma.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_fpueh.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_gpcrc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_timer_cc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_timer.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_usart.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_leuart.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_letimer.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_cryotimer.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_pcnt.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_i2c.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_adc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_acmp.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_vdac_opa.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_vdac.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense_st.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense_buf.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense_ch.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtcc_cc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtcc_ret.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtcc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtc_comp.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_wdog_pch.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_wdog.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_idac.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_smu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_trng.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_dma_descriptor.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_devinfo.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_romtable.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_prs_signals.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_dmareq.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_af_ports.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_af_pins.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_bus.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_assert.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_cmu.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_assert.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_gpio.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_common.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_common.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_core.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_system.h \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_ramfunc.h
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_emu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/em_device.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p233f256gm48.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_version.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_compiler.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_gcc.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/mpu_armv7.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/system_efr32fg14p.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_msc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_emu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rmu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_cmu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_crypto.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_gpio_p.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_gpio.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_prs_ch.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_prs.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_ldma_ch.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_ldma.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_fpueh.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_gpcrc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_timer_cc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_timer.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_usart.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_leuart.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_letimer.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_cryotimer.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_pcnt.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_i2c.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_adc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_acmp.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_vdac_opa.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_vdac.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense_st.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense_buf.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense_ch.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_lesense.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtcc_cc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtcc_ret.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtcc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtc_comp.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_rtc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_wdog_pch.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_wdog.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_idac.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_smu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_trng.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_dma_descriptor.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_devinfo.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_romtable.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_prs_signals.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_dmareq.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_af_ports.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Include/efr32fg14p_af_pins.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_bus.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_assert.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_cmu.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_assert.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_gpio.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_common.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_common.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_core.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_system.h:
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_ramfunc.h:
