build_v2/arm_common_tables.o: \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/DSP_Lib/Source/CommonTables/arm_common_tables.c \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_version.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_compiler.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_gcc.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_common_tables.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_version.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_compiler.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_gcc.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_common_tables.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h:
