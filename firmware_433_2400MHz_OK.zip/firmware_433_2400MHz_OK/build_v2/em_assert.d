build_v2/em_assert.o: \
 ../gecko_sdk_suite/v2.7/platform/emlib/src/em_assert.c \
 ../gecko_sdk_suite/v2.7/platform/emlib/inc/em_assert.h
../gecko_sdk_suite/v2.7/platform/emlib/inc/em_assert.h:
