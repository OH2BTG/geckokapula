build_v2/arm_bitreversal2.o: \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/DSP_Lib/Source/TransformFunctions/arm_bitreversal2.S
