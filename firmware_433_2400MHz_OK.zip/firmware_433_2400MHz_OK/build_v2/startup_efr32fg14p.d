build_v2/startup_efr32fg14p.o: \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32FG14P/Source/GCC/startup_efr32fg14p.S
