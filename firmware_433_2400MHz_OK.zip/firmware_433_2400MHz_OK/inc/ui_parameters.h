/* SPDX-License-Identifier: MIT */

#ifndef INC_UI_PARAMETERS_H_
#define INC_UI_PARAMETERS_H_

#define FFT_ROW1 49  // OH2BTG tässä on scrollauksen alkupaikka
#define FFT_ROW2 150 // srcollauksen loppupaikka
#define FFT_BIN1 64
#define FFT_BIN2 192

#endif /* INC_UI_PARAMETERS_H_ */
