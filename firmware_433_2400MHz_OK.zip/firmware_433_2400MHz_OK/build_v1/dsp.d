build_v1/dsp.o: src/dsp.c \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_version.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_compiler.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_gcc.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_const_structs.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_common_tables.h \
 freertos/FreeRTOS.h freertos/FreeRTOSConfig.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/em_device.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p232f256gm48.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h \
 ../gecko_sdk_suite/v2.7/platform/CMSIS/Include/mpu_armv7.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/system_efr32mg1p.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_msc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_emu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rmu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_cmu.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_crypto.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_gpio_p.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_gpio.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_prs_ch.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_prs.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_ldma_ch.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_ldma.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_fpueh.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_gpcrc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_timer_cc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_timer.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_usart.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_leuart.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_letimer.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_cryotimer.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_pcnt.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_i2c.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_adc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_acmp.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_idac.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rtcc_cc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rtcc_ret.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rtcc.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_wdog_pch.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_wdog.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_dma_descriptor.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_devinfo.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_romtable.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_prs_signals.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_dmareq.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_af_ports.h \
 ../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_af_pins.h \
 freertos/projdefs.h freertos/portable.h \
 freertos/deprecated_definitions.h freertos/portmacro.h \
 freertos/mpu_wrappers.h freertos/task.h freertos/list.h \
 freertos/semphr.h freertos/queue.h inc/rig.h inc/ui.h \
 inc/ui_parameters.h inc/dsp.h inc/dsp_math.h
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_version.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_compiler.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/cmsis_gcc.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_const_structs.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_math.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/arm_common_tables.h:
freertos/FreeRTOS.h:
freertos/FreeRTOSConfig.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/em_device.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p232f256gm48.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/core_cm4.h:
../gecko_sdk_suite/v2.7/platform/CMSIS/Include/mpu_armv7.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/system_efr32mg1p.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_msc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_emu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rmu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_cmu.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_crypto.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_gpio_p.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_gpio.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_prs_ch.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_prs.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_ldma_ch.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_ldma.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_fpueh.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_gpcrc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_timer_cc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_timer.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_usart.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_leuart.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_letimer.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_cryotimer.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_pcnt.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_i2c.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_adc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_acmp.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_idac.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rtcc_cc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rtcc_ret.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_rtcc.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_wdog_pch.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_wdog.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_dma_descriptor.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_devinfo.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_romtable.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_prs_signals.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_dmareq.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_af_ports.h:
../gecko_sdk_suite/v2.7/platform/Device/SiliconLabs/EFR32MG1P/Include/efr32mg1p_af_pins.h:
freertos/projdefs.h:
freertos/portable.h:
freertos/deprecated_definitions.h:
freertos/portmacro.h:
freertos/mpu_wrappers.h:
freertos/task.h:
freertos/list.h:
freertos/semphr.h:
freertos/queue.h:
inc/rig.h:
inc/ui.h:
inc/ui_parameters.h:
inc/dsp.h:
inc/dsp_math.h:
